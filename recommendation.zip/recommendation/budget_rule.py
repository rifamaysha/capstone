"""Budget rule 50/30/20 — analisa pengeluaran vs aturan finansial standar.

Mapping kategori → bucket:
- Kebutuhan (50%): makanan, transportasi, kesehatan, tagihan, pendidikan
- Keinginan (30%): belanja, hiburan, lainnya (default unknown)
- Tabungan  (20%): bukan dari transaksi — = pendapatan - total spent

Sumber: Elizabeth Warren, "All Your Worth: The Ultimate Lifetime Money Plan".
"""
from __future__ import annotations

from typing import Any

# Kategori → bucket
CATEGORY_TO_BUCKET: dict[str, str] = {
    "makanan_minuman": "kebutuhan",
    "transportasi":    "kebutuhan",
    "kesehatan":       "kebutuhan",
    "tagihan":         "kebutuhan",
    "pendidikan":      "kebutuhan",
    "belanja":         "keinginan",
    "hiburan":         "keinginan",
    "lainnya":         "keinginan",
}

BUCKET_DISPLAY: dict[str, str] = {
    "kebutuhan": "Kebutuhan",
    "keinginan": "Keinginan",
    "tabungan":  "Tabungan",
}

IDEAL_RATIO: dict[str, float] = {
    "kebutuhan": 0.50,
    "keinginan": 0.30,
    "tabungan":  0.20,
}


def analyze_budget(
    transactions: list[dict[str, Any]],
    monthly_income: float,
) -> dict[str, Any]:
    """Analisa transaksi vs aturan 50/30/20.

    Args:
        transactions: list of dict, masing-masing harus punya:
            - 'amount' (float)
            - 'category' (string, salah satu dari 8 kategori)
        monthly_income: pendapatan bulanan user (Rp).

    Returns:
        Dict berisi total per bucket, rasio aktual, perbandingan vs ideal,
        dan list rekomendasi.
    """
    if monthly_income <= 0:
        raise ValueError("monthly_income harus > 0")

    bucket_totals = {"kebutuhan": 0.0, "keinginan": 0.0}
    by_category: dict[str, float] = {}

    for tx in transactions:
        cat = tx.get("category", "lainnya")
        amt = float(tx.get("amount") or 0)
        if amt <= 0:
            continue
        bucket = CATEGORY_TO_BUCKET.get(cat, "keinginan")
        bucket_totals[bucket] += amt
        by_category[cat] = by_category.get(cat, 0.0) + amt

    total_spent = sum(bucket_totals.values())
    tabungan = max(0.0, monthly_income - total_spent)

    actual_ratio = {
        "kebutuhan": bucket_totals["kebutuhan"] / monthly_income,
        "keinginan": bucket_totals["keinginan"] / monthly_income,
        "tabungan":  tabungan / monthly_income,
    }

    # Generate rekomendasi (toleransi ±5% dari ideal)
    recs: list[str] = []
    if actual_ratio["kebutuhan"] > 0.55:
        over = (actual_ratio["kebutuhan"] - 0.50) * monthly_income
        recs.append(
            f"Pengeluaran Kebutuhan {actual_ratio['kebutuhan']:.0%} "
            f"(ideal ≤50%). Over Rp {over:,.0f} — review tagihan & "
            f"transportasi."
        )
    if actual_ratio["keinginan"] > 0.35:
        over = (actual_ratio["keinginan"] - 0.30) * monthly_income
        recs.append(
            f"Pengeluaran Keinginan {actual_ratio['keinginan']:.0%} "
            f"(ideal ≤30%). Bisa hemat Rp {over:,.0f} — kurangi belanja "
            f"atau hiburan."
        )
    if actual_ratio["tabungan"] < 0.15:
        short = (0.20 - actual_ratio["tabungan"]) * monthly_income
        recs.append(
            f"Tabungan {actual_ratio['tabungan']:.0%} "
            f"(target ≥20%). Kurang Rp {short:,.0f} dari ideal."
        )
    if not recs:
        recs.append("Pola pengeluaran sesuai aturan 50/30/20. Pertahankan!")

    return {
        "income":          monthly_income,
        "total_spent":     total_spent,
        "bucket_totals":   bucket_totals,
        "tabungan":        tabungan,
        "actual_ratio":    actual_ratio,
        "ideal_ratio":     IDEAL_RATIO,
        "by_category":     by_category,
        "recommendations": recs,
    }