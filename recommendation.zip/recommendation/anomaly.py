"""Anomaly detection — Isolation Forest pada nilai transaksi.

Tujuan: identifikasi transaksi yang amount-nya jauh dari pola normal user.
Misal: rata-rata makan Rp 25k, tiba-tiba ada Rp 250k → flagged.
"""
from __future__ import annotations

from typing import Any

import numpy as np
from sklearn.ensemble import IsolationForest


def detect_anomalies(
    transactions: list[dict[str, Any]],
    contamination: float = 0.1,
    min_samples: int = 5,
    by_category: bool = True,
    random_state: int = 42,
) -> list[dict[str, Any]]:
    """Deteksi transaksi outlier dengan Isolation Forest.

    Args:
        transactions: list of dict, harus punya 'amount' (dan 'category' kalau
            by_category=True).
        contamination: estimasi proporsi outlier (default 10%).
        min_samples: minimum transaksi untuk fit model (default 5).
        by_category: jika True, fit per kategori (lebih akurat); jika False,
            fit semua transaksi sekaligus.
        random_state: seed reproducibility.

    Returns:
        List transaksi outlier, masing-masing ditambahkan field:
            - 'anomaly_score' (float, makin negatif makin outlier)
            - 'is_anomaly': True
    """
    if len(transactions) < min_samples:
        return []

    if not by_category:
        return _detect_in_group(transactions, contamination, random_state)

    # Group per kategori, fit terpisah
    by_cat: dict[str, list[dict[str, Any]]] = {}
    for tx in transactions:
        cat = tx.get("category", "lainnya")
        by_cat.setdefault(cat, []).append(tx)

    anomalies: list[dict[str, Any]] = []
    for cat, txs in by_cat.items():
        if len(txs) < min_samples:
            continue
        anomalies.extend(_detect_in_group(txs, contamination, random_state))
    return anomalies


def _detect_in_group(
    transactions: list[dict[str, Any]],
    contamination: float,
    random_state: int,
) -> list[dict[str, Any]]:
    """Fit Isolation Forest pada satu grup transaksi, return outliers."""
    amounts = np.array(
        [float(t.get("amount") or 0) for t in transactions]
    ).reshape(-1, 1)

    model = IsolationForest(
        contamination=contamination,
        random_state=random_state,
        n_estimators=100,
    )
    predictions = model.fit_predict(amounts)
    scores = model.score_samples(amounts)

    outliers: list[dict[str, Any]] = []
    for tx, pred, score in zip(transactions, predictions, scores):
        if pred == -1:  # IsolationForest: -1 = outlier
            tx_out = dict(tx)
            tx_out["anomaly_score"] = float(score)
            tx_out["is_anomaly"] = True
            outliers.append(tx_out)
    return outliers