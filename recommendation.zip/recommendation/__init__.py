"""Recommendation engine: 50/30/20 budget rule + Isolation Forest anomaly."""
from .budget_rule import (
    CATEGORY_TO_BUCKET,
    BUCKET_DISPLAY,
    IDEAL_RATIO,
    analyze_budget,
)
from .anomaly import detect_anomalies

__all__ = [
    "CATEGORY_TO_BUCKET",
    "BUCKET_DISPLAY",
    "IDEAL_RATIO",
    "analyze_budget",
    "detect_anomalies",
]