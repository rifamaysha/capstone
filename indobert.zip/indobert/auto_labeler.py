"""Auto-label record berdasarkan keyword heuristic + mapping Kaggle."""
from __future__ import annotations

import logging
import re
from typing import Any

from .categories import (
    CATEGORIES,
    KAGGLE_CATEGORY_MAP,
    KEYWORDS_BY_CATEGORY,
)

logger = logging.getLogger(__name__)


# Pre-compile regex per kategori — escape supaya brand dengan karakter
# spesial (e.g., "j.co", "h&m") tidak crash, dan word-boundary biar
# substring tidak salah match (misal "pasar" tidak match "pasarana").
_KEYWORD_REGEX: dict[str, re.Pattern] = {
    cat: re.compile(
        r"(?<!\w)(?:" + "|".join(re.escape(kw) for kw in keywords) + r")(?!\w)",
        re.IGNORECASE,
    )
    for cat, keywords in KEYWORDS_BY_CATEGORY.items()
    if keywords
}


def label_text(text: str | None) -> tuple[str, dict[str, int]]:
    """Klasifikasi text → (kategori_terbaik, counts_per_kategori).

    Args:
        text: Teks bebas yang akan diklasifikasi (mis. nama merchant atau
            gabungan nama menu).

    Returns:
        Tuple (kategori, counts). Kategori = yang punya keyword match
        terbanyak. Kalau tidak ada match → 'lainnya' dan counts = {}.
    """
    if not text:
        return "lainnya", {}

    counts: dict[str, int] = {}
    for cat, regex in _KEYWORD_REGEX.items():
        n = len(regex.findall(text))
        if n:
            counts[cat] = n

    if not counts:
        return "lainnya", {}

    # Tie-break: kategori dengan match terbanyak menang
    best = max(counts.items(), key=lambda kv: kv[1])[0]
    return best, counts


def label_record(record: dict[str, Any]) -> str:
    """Auto-label satu record unified.

    Strategi prioritas:
    1. Kaggle dengan field 'category' valid → mapping langsung
       (paling reliable karena annotated manual oleh dataset asli).
    2. M-Banking dengan merchant → keyword match dari merchant
       (lebih informatif daripada gabungan kata "Bagibukti bayar" dst).
    3. Lain-lain → keyword match dari `text_for_classification`.

    Args:
        record: Dict dari unified JSONL (hasil build_dataset.py).

    Returns:
        String kategori internal (salah satu dari `CATEGORIES`).
    """
    source = record.get("source")
    raw_category = (record.get("category") or "").strip().lower()

    # Jalur 1: Kaggle native category
    if source == "kaggle" and raw_category in KAGGLE_CATEGORY_MAP:
        return KAGGLE_CATEGORY_MAP[raw_category]

    # Jalur 2: M-Banking — merchant (recipient) lebih informatif
    if source == "mbanking" and record.get("merchant"):
        cat, _ = label_text(record["merchant"])
        return cat

    # Jalur 3: fallback ke text_for_classification (CORD: nama menu joined)
    cat, _ = label_text(record.get("text_for_classification"))
    return cat
