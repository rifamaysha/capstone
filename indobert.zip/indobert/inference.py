"""Inference utility — pakai model IndoBERT terlatih untuk predict kategori."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import torch
from transformers import AutoModelForSequenceClassification, AutoTokenizer


class CategoryClassifier:
    """Wrapper inference IndoBERT terlatih.

    Load sekali di __init__, lalu pakai predict() berkali-kali.
    """

    def __init__(self, model_dir, max_length: int = 128) -> None:
        model_dir = Path(model_dir)
        if not model_dir.exists():
            raise FileNotFoundError(f"Model directory not found: {model_dir}")

        self.tokenizer = AutoTokenizer.from_pretrained(str(model_dir))
        self.model = AutoModelForSequenceClassification.from_pretrained(str(model_dir))
        self.model.eval()
        self.max_length = max_length

        meta_path = model_dir / "training_metadata.json"
        if not meta_path.exists():
            raise FileNotFoundError(f"training_metadata.json not in {model_dir}")
        with open(meta_path, encoding="utf-8") as f:
            self.metadata = json.load(f)
        self.id_to_label = {int(k): v for k, v in self.metadata["id_to_label"].items()}

    def predict(self, text: str, return_probs: bool = False):
        if not text or not text.strip():
            return {"label": "lainnya", "confidence": 0.0}

        enc = self.tokenizer(
            text,
            max_length=self.max_length,
            padding="max_length",
            truncation=True,
            return_tensors="pt",
        )

        with torch.no_grad():
            logits = self.model(**enc).logits[0]
            probs = torch.softmax(logits, dim=-1)
            pred_id = int(torch.argmax(probs).item())

        out = {
            "label": self.id_to_label[pred_id],
            "confidence": float(probs[pred_id].item()),
        }
        if return_probs:
            out["probs"] = {
                self.id_to_label[i]: float(p.item())
                for i, p in enumerate(probs)
            }
        return out

    def predict_batch(self, texts):
        return [self.predict(t) for t in texts]
