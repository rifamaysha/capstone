"""Hybrid classifier — keyword 3 tier + IndoBERT.

Tier 1: word-boundary keyword (dari auto_labeler.label_text)
Tier 2: substring (untuk compound: 'Abyfood' → food → Makanan)
Tier 3: kata-makanan-Indonesia word-boundary (untuk: 'Sop Burtok' → sop → Makanan,
        tapi NOT 'Sopir' karena pakai \\b)
Tier 4: IndoBERT fallback
"""
from __future__ import annotations

import re
from pathlib import Path
from typing import Any

from .auto_labeler import label_text
from .inference import CategoryClassifier


_SUBSTRING_PATTERNS: dict[str, list[str]] = {
    "makanan_minuman": [
        "food", "cafe", "kafe", "kopi", "warkop", "warung",
        "resto", "restoran", "bakery", "depot", "dapur",
        "donut", "pizza", "burger",
        "bread", "roti", "cream", "tea", "teh", "milk", "susu",
        "frestea", "minerale", "aice", "cimory",
    ],
    "kesehatan": [
        "klinik", "clinic", "dental", "apotek", "apotik",
        "pharmacy", "medical", "hospital",
    ],
    "pendidikan": [
        "bimbel", "kursus", "sekolah", "school",
        "kampus", "universitas", "academy",
    ],
    "hiburan": [
        "hotel", "resort", "villa", "cinema", "karaoke", "bioskop",
    ],
    "belanja": [
        "mart", "store", "shop", "minimart", "supermart",
    ],
    "transportasi": [
        "rental", "taksi", "travel",
    ],
    "tagihan": [
        "wifi", "pulsa",
    ],
}

# Kata pendek yang HARUS pakai word-boundary (case insensitive) supaya tidak
# false-match "Sopir", "Sophie", "Aymara" dst.
_WORD_PATTERNS: dict[str, list[str]] = {
    "makanan_minuman": [
        "sop", "soto", "bakso", "mie", "mi", "nasi", "ayam",
        "ketoprak", "gado-gado", "gado gado", "rumah makan",
        "bubur", "rendang", "padang", "sate", "iga", "konro",
        "burtok", "lalapan", "pecel", "rawon",
    ],
}

# Pre-compile regex word-boundary patterns
_WORD_REGEX = {
    cat: [re.compile(rf"\b{re.escape(w)}\b", re.IGNORECASE) for w in words]
    for cat, words in _WORD_PATTERNS.items()
}


def _check_substring(text: str) -> dict[str, int]:
    text_lower = text.lower()
    counts: dict[str, int] = {}
    for cat, keywords in _SUBSTRING_PATTERNS.items():
        for kw in keywords:
            if kw in text_lower:
                counts[cat] = counts.get(cat, 0) + 1
    return counts


def _check_word_boundary(text: str) -> dict[str, int]:
    counts: dict[str, int] = {}
    for cat, patterns in _WORD_REGEX.items():
        for pat in patterns:
            n = len(pat.findall(text))
            if n > 0:
                counts[cat] = counts.get(cat, 0) + n
    return counts


class HybridCategoryClassifier:
    """Keyword tiered + IndoBERT untuk 8 kategori."""

    def __init__(self, model_dir: str | Path) -> None:
        self.bert = CategoryClassifier(model_dir)

    def predict(self, text: str) -> dict[str, Any]:
        if not text or not text.strip():
            return {"label": "lainnya", "confidence": 0.0, "source": "empty"}

        # Run ALL keyword detectors
        _, kw_counts = label_text(text)
        substr_counts = _check_substring(text)
        word_counts = _check_word_boundary(text)

        # Merge counts
        combined: dict[str, int] = {}
        for source_dict in (kw_counts, substr_counts, word_counts):
            for cat, c in source_dict.items():
                if cat == "lainnya":
                    continue
                combined[cat] = combined.get(cat, 0) + c

        if combined:
            best_cat = max(combined.keys(), key=lambda k: combined[k])
            return {
                "label":       best_cat,
                "confidence":  0.90,
                "source":      "keyword",
                "match_count": combined[best_cat],
            }

        # Fallback IndoBERT
        result = self.bert.predict(text)
        result["source"] = "indobert"
        return result