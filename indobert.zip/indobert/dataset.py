"""PyTorch Dataset untuk classifier kategori transaksi."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import torch
from torch.utils.data import Dataset
from transformers import PreTrainedTokenizerBase

from .config import COLLAPSE_MAP


def build_input_text(record: dict[str, Any]) -> str:
    """Buat string input classifier dari record unified.

    Strategi: gabungkan merchant (kalau ada) dengan text_for_classification.
    Untuk M-Banking biasanya cuma merchant; untuk CORD cuma item names;
    untuk Kaggle ada teks panjang dari annotations.
    """
    merchant = (record.get("merchant") or "").strip()
    items    = (record.get("text_for_classification") or "").strip()
    if merchant and items:
        return f"{merchant} {items}"
    return merchant or items


class CategoryDataset(Dataset):
    """Dataset klasifikasi: text → kategori (5 kelas).

    Membaca *_labeled.jsonl, collapse label ke 5 kelas aktif,
    dan tokenize on-the-fly per __getitem__.
    """

    def __init__(
        self,
        jsonl_path: Path,
        tokenizer: PreTrainedTokenizerBase,
        label_to_id: dict[str, int],
        max_length: int = 128,
    ) -> None:
        if not jsonl_path.exists():
            raise FileNotFoundError(f"JSONL not found: {jsonl_path}")

        self.tokenizer = tokenizer
        self.label_to_id = label_to_id
        self.max_length = max_length

        self.samples: list[dict[str, Any]] = []
        with open(jsonl_path, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                r = json.loads(line)
                raw_label = r.get("category_label", "lainnya")
                # Collapse ke active class
                collapsed = COLLAPSE_MAP.get(raw_label, "lainnya")
                text = build_input_text(r)
                if not text:
                    continue
                self.samples.append({"text": text, "label": collapsed})

    def __len__(self) -> int:
        return len(self.samples)

    def __getitem__(self, idx: int) -> dict[str, torch.Tensor]:
        sample = self.samples[idx]
        encoding = self.tokenizer(
            sample["text"],
            max_length=self.max_length,
            padding="max_length",
            truncation=True,
            return_tensors="pt",
        )
        return {
            "input_ids":      encoding.input_ids.squeeze(0),
            "attention_mask": encoding.attention_mask.squeeze(0),
            "labels":         torch.tensor(
                self.label_to_id[sample["label"]], dtype=torch.long,
            ),
        }
    