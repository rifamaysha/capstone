"""Skema kategori pengeluaran personal + keyword dictionary."""
from __future__ import annotations

# 8 kategori internal — string ID dipakai sebagai label training IndoBERT.
# Urutan sini menentukan label_id (idx 0..7).
CATEGORIES: list[str] = [
    "makanan_minuman",
    "transportasi",
    "belanja",
    "hiburan",
    "kesehatan",
    "pendidikan",
    "tagihan",
    "lainnya",
]

# Display name untuk UI Streamlit nanti
CATEGORY_DISPLAY: dict[str, str] = {
    "makanan_minuman": "Makanan & Minuman",
    "transportasi":    "Transportasi",
    "belanja":         "Belanja & Retail",
    "hiburan":         "Hiburan & Wisata",
    "kesehatan":       "Kesehatan",
    "pendidikan":      "Pendidikan",
    "tagihan":         "Tagihan & Utilitas",
    "lainnya":         "Lainnya",
}

# Mapping label Kaggle (English asli) → kategori internal
# Mengandalkan field 'category' yang sudah ada di train_list.csv
KAGGLE_CATEGORY_MAP: dict[str, str] = {
    "restaurant":          "makanan_minuman",
    "retail":              "belanja",
    "hotel":               "hiburan",
    "tourist attraction":  "hiburan",
    "public transport":    "transportasi",
    "taxi":                "transportasi",
}

# Keyword dictionary untuk auto-labeling text Indonesia.
# Masing-masing keyword di-match dengan word boundary (\b) — case-insensitive.
# Tambahkan keyword baru kalau distribusi label terlalu banyak "lainnya".
KEYWORDS_BY_CATEGORY: dict[str, list[str]] = {
    "makanan_minuman": [
        # Tempat makan umum
        "warung", "warmindo", "kantin", "restoran", "resto", "rumah makan",
        "cafe", "café", "coffee", "kopi", "kedai", "depot", "bistro", "diner",
        # Brand makanan/minuman besar
        "starbucks", "kfc", "mcd", "mcdonald", "burger king", "pizza hut",
        "j.co", "dunkin", "chatime", "kopikenangan", "kopi kenangan",
        "janji jiwa", "fore", "tuku", "common grounds", "kopi 88",
        "yoshinoya", "hokben", "solaria", "ichiban sushi", "sushi tei",
        "marugame", "ramen ya", "paris baguette", "holland bakery",
        "sour sally", "krispy kreme", "auntie anne", "haagen dazs",
        "es teler", "ayam geprek", "geprek bensu",
        # Jenis makanan Indonesia
        "ayam", "nasi", "mie", "mi ", "bakso", "soto", "sate", "rendang",
        "rawon", "gado", "ketoprak", "tahu", "tempe", "lontong", "ketupat",
        "tukang ayam", "ayam goreng", "fried chicken", "ayam bakar",
        "bebek", "ikan bakar", "ikan goreng", "udang", "cumi",
        "cireng", "batagor", "siomay", "bakwan", "kerupuk", "keripik",
        "es teh", "teh manis", "kue", "puding", "es campur", "es krim",
        "ice cream", "icecream",
        # Western / Asian
        "steak", "pasta", "spaghetti", "salad", "ramen", "udon", "soba",
        "sushi", "sashimi", "tempura", "takoyaki", "gyoza", "dimsum",
        "dim sum", "dumpling", "sandwich", "wrap", "bowl", "soup",
        "pancake", "waffle", "burger", "hotdog", "hot dog", "pizza",
        "fried rice", "fried noodle", "kimchi", "bulgogi", "tteokbokki",
        "ramyeon", "kimbap", "bibimbap",
        # Bakery / pastry / dessert
        "donut", "doughnut", "donat", "pastry", "croissant", "brownies",
        "brownie", "muffin", "cake", "cupcake", "cheesecake", "croffle",
        "danish", "eclair", "churros", "tart", "scone", "cookies",
        "cookie", "biscuit", "biskuit", "roti", "bread", "bagel",
        "ganache", "creamcheese", "cream cheese", "custard", "choco",
        "chocolate", "matcha", "vanilla", "strawberry", "blueberry",
        "almond", "peach", "apple", "real",
        # Minuman
        "latte", "cappuccino", "cappucino", "espresso", "americano",
        "frappe", "frappuccino", "mocha", "macchiato",
        "tea", "teh", "lemon tea", "milk tea", "boba", "taro",
        "jus", "juice", "smoothie", "milkshake", "lemonade", "soda",
        "thai tea", "yakult", "yogurt", "yoghurt",
        # Aplikasi food delivery
        "gofood", "grabfood", "shopeefood",
        # Generic
        "makan", "minum", "sarapan", "breakfast", "lunch", "dinner",
        "snack", "cemilan", "menu", "set menu", "paket",
        "rice", "noodle", "chicken", "beef", "pork", "fish",
        # CORD-specific food items yang lolos di iterasi sebelumnya
        "milo", "toast", "white toast", "garlic toast",
        "bento", "donburi", "katsu", "tonkatsu", "satsuma",
        "kimbap", "japchae", "bibim", "bibimbap", "sogogi",
        "gyeran", "miso", "ramyun", "ramyeon",
        "tempura", "surimi", "calamari", "robata", "robatayaki",
        "combo", "combo 1", "combo 2", "set a", "set b",
        "cream brulee", "creme brulee", "brulee",
        "cheesecake", "cheese cake", "cheese tart", "cheese roll",
        "cocktail", "tonic", "tanqueray", "lurisia", "stille",
        "filet", "salmon", "tuna", "prawn", "lobster",
        "tongseng", "pandan", "vanilla cream",
    ],
    "transportasi": [
        "shell", "pertamina", "spbu", "bp ", "vivo", "pertalite",
        "pertamax", "dexlite", "solar", "premium",
        "gojek", "goride", "gocar", "grab", "grabbike", "grabcar",
        "indriver", "maxim", "blue bird", "bluebird", "ojek", "ojol",
        "tol", "jalan tol", "e-toll", "etoll", "gtag", "parkir", "parking",
        "transjakarta", "krl", "kai", "mrt", "lrt", "kereta",
        "tiket bus", "damri", "busway",
        "e-money", "flazz", "tiket kereta",
    ],
    "belanja": [
        # Minimarket / supermarket
        "alfamart", "indomaret", "alfamidi", "circle k", "lawson",
        "carrefour", "transmart", "hypermart", "superindo", "ranch market",
        "matahari", "ramayana", "hero", "lottemart", "naga", "lulu",
        "giant", "guardian",
        # E-commerce
        "tokopedia", "shopee", "lazada", "bukalapak", "blibli",
        # Fashion brand
        "samsung", "iphone", "apple", "adidas", "nike", "uniqlo", "h&m",
        "valino", "donna", "polo", "levis", "vans", "converse", "fila",
        "puma", "zara", "pull&bear", "bershka", "stradivarius", "mango",
        # Cosmetics
        "wardah", "somethincl", "emina", "maybelline", "loreal", "l'oreal",
        "the body shop", "innisfree", "sephora", "watsons",
        # Items
        "baju", "celana", "sepatu", "shoe", "shoes", "sandal", "tas",
        "dompet", "wallet", "kaos", "t-shirt", "kemeja", "shirt", "jaket",
        "jacket", "sweater", "hoodie", "dress", "rok", "skirt", "jeans",
        "sneakers", "kosmetik", "lipstick", "lipstik", "powder", "bedak",
        "size 36", "size 37", "size 38", "size 39", "size 40", "size 41",
        "size 42", "size 43", "size 44", "size 45", "size 45.5",
        # Electronics
        "laptop", "smartphone", "charger", "cable", "kabel",
        "headphone", "earphone", "speaker", "power bank", "casing",
        # Furniture / hardware
        "ikea", "ace hardware", "informa", "ace ",
        # Generic
        "shopping", "retail", "mall", "plaza", "supermarket", "minimarket",
        # Local retail / mall yang sering muncul di M-Banking
        "borma", "yogya", "griya", "asia toserba", "toserba",
        "summarecon", "summarecon mall", "trans studio mall",
        "kota kasablanka", "central park", "grand indonesia",
        # Stationery / craft / hobby
        "wacom", "bamboo pen", "pen", "pulpen", "buku tulis",
        "stationery", "alat tulis", "kado", "gift",
        # Toys
        "toys", "mainan", "boneka", "lego", "doll", "action figure",
    ],
    "hiburan": [
        "cinepolis", "cgv", "xxi", "cinema", "bioskop",
        "spotify", "netflix", "disney", "youtube premium", "vidio", "viu",
        "trans studio", "dufan", "ancol", "tiket masuk", "wisata",
        "taman safari", "candi", "museum",
        "hotel", "villa", "homestay", "airbnb", "oyo", "reddoorz",
        "santika", "ibis", "amaris", "novotel", "harris", "marriot",
        "karaoke", "inul", "nav", "bowling", "billiard",
        "traveloka", "tiket.com", "agoda", "booking.com", "pegipegi",
        "steam", "playstation", "xbox", "nintendo",
        "gym", "fitness", "celebrity fitness", "gold's gym",
    ],
    "kesehatan": [
        "dental", "dokter", "klinik", "rumah sakit", "rs ", "rsud", "rsia",
        "apotek", "apotik", "kimia farma", "century",
        "puskesmas", "prodia", "pramita",
        "vitamin", "obat", "masker", "suplemen", "medical", "hospital",
        "bpjs kesehatan",
        "namina farma", "k24", "k-24", "kf ",
        "bengkuang masker",  # CORD ada masker jadi
        "salonpas", "panadol", "paracetamol", "antibiotik",
    ],
    "pendidikan": [
        "kampus", "sekolah", "universitas", "kursus", "bimbel", "les",
        "buku", "gramedia", "togamas", "ruangguru", "zenius",
        "quipper", "primagama", "ganesha", "training", "workshop", "seminar",
    ],
    "tagihan": [
        "pln", "listrik", "pdam", "air pam", "token listrik",
        "indihome", "first media", "biznet", "myrepublic", "iconnet",
        "telkomsel", "xl axiata", "indosat", "smartfren", "by.u", "tri ",
        "telkom", "axis",
        "pulsa", "paket data", "kuota",
        "premi", "asuransi", "bpjs", "subscription", "langganan",
        "blackbox", "youtube", "spotify premium",  # subscription
    ],
}
