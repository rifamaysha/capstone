"""Konfigurasi training & inference IndoBERT classifier."""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

PROJECT_ROOT = Path(r"C:\Users\USER\Documents\CAPSTONE")
DATA_DIR    = PROJECT_ROOT / "data_processed" / "unified"
MODEL_OUT   = PROJECT_ROOT / "models" / "indobert"

# Kelas aktif untuk training (subset dari 8 di CATEGORIES).
# Kelas dengan <10 sample di-collapse ke 'lainnya' biar IndoBERT bisa belajar.
ACTIVE_CLASSES: list[str] = [
    "makanan_minuman",
    "transportasi",
    "belanja",
    "hiburan",
    "lainnya",
]

# Mapping schema 8-class → 5-class training
COLLAPSE_MAP: dict[str, str] = {
    "makanan_minuman": "makanan_minuman",
    "transportasi":    "transportasi",
    "belanja":         "belanja",
    "hiburan":         "hiburan",
    # 3 kelas tipis di-collapse:
    "kesehatan":       "lainnya",
    "pendidikan":      "lainnya",
    "tagihan":         "lainnya",
    "lainnya":         "lainnya",
}


@dataclass
class TrainingConfig:
    """Hyperparameter training IndoBERT."""
    base_model: str = "indobenchmark/indobert-base-p1"

    max_length: int = 128         # cukup untuk merchant + 5-10 item
    num_epochs: int = 8
    batch_size: int = 8           # CPU-friendly
    learning_rate: float = 2e-5
    warmup_ratio: float = 0.1
    weight_decay: float = 0.01

    use_class_weight: bool = True  # handle imbalance
    save_total_limit: int = 2
    seed: int = 42